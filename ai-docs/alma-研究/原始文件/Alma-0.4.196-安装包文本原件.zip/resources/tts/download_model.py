#!/usr/bin/env python3
"""Download Qwen3-TTS model with JSON progress reporting to stdout."""
import os
import sys
import json
import time
import threading


def main():
    models_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "models"
    )
    repo_id = "mlx-community/Qwen3-TTS-12Hz-1.7B-CustomVoice-8bit"
    target = os.path.join(models_dir, "CustomVoice-1.7B")

    os.makedirs(models_dir, exist_ok=True)

    def report(msg):
        print(json.dumps(msg), flush=True)

    # Check if model already exists
    if os.path.exists(target):
        has_weights = False
        for root, _, files in os.walk(target):
            for name in files:
                if name.endswith((".safetensors", ".npz", ".bin")):
                    has_weights = True
                    break
            if has_weights:
                break
        if has_weights:
            report({"status": "success", "message": "Model already downloaded.", "done": True})
            return

    # Use HF mirror if HF_ENDPOINT is set (e.g. for China), or auto-detect
    hf_endpoint = os.environ.get("HF_ENDPOINT", "")
    if not hf_endpoint:
        # Auto-detect: try the official endpoint first with a short timeout
        try:
            import urllib.request
            req = urllib.request.Request("https://huggingface.co", method="HEAD")
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            # Official endpoint unreachable, use mirror
            hf_endpoint = "https://hf-mirror.com"
            os.environ["HF_ENDPOINT"] = hf_endpoint
            report({"status": "progress",
                    "message": "Using HuggingFace mirror (hf-mirror.com)..."})

    # Disable hf-xet transfer to use standard HTTPS (works better with proxies)
    os.environ["HF_HUB_ENABLE_HF_TRANSFER"] = "0"

    # Verify huggingface_hub is available before proceeding
    try:
        import huggingface_hub  # noqa: F401
    except ImportError:
        report({
            "status": "error",
            "message": "Missing Python dependency: huggingface_hub. "
                       "Please re-run TTS setup from Alma settings to install dependencies.",
            "done": True,
            "error": True,
        })
        sys.exit(1)

    # Get repo size
    total_size = 0
    try:
        from huggingface_hub import HfApi
        api = HfApi()
        info = api.repo_info(repo_id)
        total_size = sum(s.size for s in info.siblings if s.size)
    except Exception:
        pass
    # Fallback when API doesn't report sizes (common with xet/LFS files)
    if total_size <= 0:
        total_size = int(2.2 * 1024 * 1024 * 1024)  # ~2.2GB

    report({"status": "downloading", "message": "Starting model download...",
            "total": total_size, "downloaded": 0, "speed": 0})

    # Monitor download progress in background
    done = threading.Event()

    def get_dir_size(dirpath):
        total = 0
        if not os.path.exists(dirpath):
            return 0
        for root, dirs, files in os.walk(dirpath):
            # Skip hidden dirs like .cache to avoid counting temp download files
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            for f in files:
                if f.startswith('.'):
                    continue
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return total

    def monitor():
        last_size = 0
        last_time = time.time()
        while not done.wait(timeout=1.0):
            current_size = get_dir_size(target)
            now = time.time()
            elapsed = now - last_time
            speed = (current_size - last_size) / elapsed if elapsed > 0 else 0
            last_size = current_size
            last_time = now
            report({
                "status": "downloading",
                "downloaded": current_size,
                "total": total_size,
                "speed": speed,
            })

    monitor_thread = threading.Thread(target=monitor, daemon=True)
    monitor_thread.start()

    try:
        from huggingface_hub import snapshot_download
        snapshot_download(
            repo_id=repo_id,
            local_dir=target,
        )
        done.set()
        final_size = get_dir_size(target)
        report({
            "status": "success",
            "message": "Model download complete.",
            "downloaded": final_size,
            "total": total_size,
            "done": True,
        })
    except Exception as e:
        done.set()
        report({"status": "error", "message": str(e), "done": True, "error": True})
        sys.exit(1)


if __name__ == "__main__":
    main()
