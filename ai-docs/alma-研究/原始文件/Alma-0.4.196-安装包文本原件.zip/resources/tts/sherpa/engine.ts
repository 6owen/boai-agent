/**
 * On-device speech synthesis runtime (ports `tts_sherpa.go` + `tts_runtime.go`).
 *
 *   - lazy model download (with progress events) on first synthesis
 *   - markdown-stripped text -> sentence chunks -> base64 WAV
 *
 * IMPORTANT: actual sherpa-onnx synthesis runs in a separate **bun** process
 * (see worker-client.ts / tts-worker.cjs), NOT in the Electron main process.
 * Electron's V8 build forbids the external ArrayBuffers sherpa returns
 * ("External buffers are not allowed"), and synthesis is CPU-heavy enough to
 * freeze the main thread. The main process only does cage-safe work here:
 * model download, text cleaning, and WAV encoding on copied sample buffers.
 */

import { EventEmitter } from 'events';
import { dominantSpeechLang, splitSpeechSentences, stripMarkdownForSpeech } from './text-clean';
import { applyEdgeFades, encodeWAV, normalizePeak } from './wav';
import {
    DownloadProgress,
    SpeechLang,
    defaultKokoroPaths,
    defaultMeloPaths,
    ensureKokoroAssets,
    ensureMeloAssets,
    fileExistsAndNonEmpty,
    kokoroModelPresent,
    meloModelPresent,
    removeModelForLang,
    ttsModelPresentForLang,
} from './models';
import { sherpaWorker } from './worker-client';

/** Build the sherpa OfflineTts config for a language (sent to the worker). */
function configForLang(lang: SpeechLang): unknown {
    if (lang === 'en') {
        const paths = defaultKokoroPaths();
        return {
            model: {
                kokoro: {
                    model: paths.model,
                    voices: paths.voices,
                    tokens: paths.tokens,
                    dataDir: paths.dataDir,
                    lengthScale: 1.0,
                },
                numThreads: 2,
                provider: 'cpu',
            },
            maxNumSentences: 2,
        };
    }
    const paths = defaultMeloPaths();
    const fsts = [paths.phoneFst, paths.dateFst, paths.numberFst].filter(fileExistsAndNonEmpty);
    return {
        model: {
            vits: {
                model: paths.model,
                lexicon: paths.lexicon,
                tokens: paths.tokens,
                noiseScale: 0.667,
                noiseScaleW: 0.8,
                lengthScale: 1.0,
            },
            numThreads: 2,
            provider: 'cpu',
        },
        ruleFsts: fsts.join(','),
        maxNumSentences: 2,
    };
}

export interface TtsModelStatus {
    zh: boolean;
    en: boolean;
}

/** Returns true when on-device synthesis can run (bundled bun + worker + addon). */
export async function isSherpaAvailable(): Promise<boolean> {
    return sherpaWorker.available();
}

/**
 * Events emitted during model download / load. Consumed by the SSE route so
 * the renderer can show download-progress toasts.
 *   - 'download-progress' { lang, fileName, downloaded, total, bytesPerSec }
 *   - 'model-ready'       { lang }
 *   - 'model-error'       { lang, message }
 *   - 'model-cancelled'   { lang }
 */
export const ttsEvents = new EventEmitter();
ttsEvents.setMaxListeners(50);

const ready = new Set<SpeechLang>();
const loading = new Map<SpeechLang, Promise<void>>();

function downloadProgress(lang: SpeechLang): DownloadProgress {
    return (fileName, downloaded, total, bytesPerSec) => {
        ttsEvents.emit('download-progress', { lang, fileName, downloaded, total, bytesPerSec });
    };
}

/** Ensure the model for `lang` is downloaded + extracted (serialized first load). */
async function ensureReadyForLang(lang: SpeechLang, signal?: AbortSignal): Promise<void> {
    // Disk is the source of truth — re-check every time so deleting the model
    // files on disk reliably triggers a fresh download (don't trust an
    // in-memory "ready" flag, which would skip the download after the files are
    // removed out from under us).
    if (ttsModelPresentForLang(lang)) {
        ready.add(lang);
        return;
    }
    ready.delete(lang);

    const inFlight = loading.get(lang);
    if (inFlight) {
        return inFlight;
    }

    const task = (async () => {
        const progress = downloadProgress(lang);
        // The model is absent (checked above) — announce the download is starting
        // so the progress toast appears immediately, before the first byte.
        progress('', 0, 0, 0);
        if (lang === 'en') {
            await ensureKokoroAssets(defaultKokoroPaths(), progress, signal);
        } else {
            await ensureMeloAssets(defaultMeloPaths(), progress, signal);
        }
        ready.add(lang);
        console.log(`[tts] ${lang} model ready`);
        ttsEvents.emit('model-ready', { lang });
    })();

    loading.set(lang, task);
    try {
        await task;
    } finally {
        loading.delete(lang);
    }
}

/** Clean + synthesize text, returning a 16-bit mono WAV buffer. */
export async function synthesizeSpeechWav(text: string): Promise<Buffer> {
    const clean = stripMarkdownForSpeech(text);
    if (clean === '') {
        throw new Error('no speakable text');
    }
    const lang = dominantSpeechLang(clean) as SpeechLang;
    try {
        await ensureReadyForLang(lang);
    } catch (err) {
        ttsEvents.emit('model-error', { lang, message: err instanceof Error ? err.message : String(err) });
        throw err;
    }
    const { sampleRate, samples } = await sherpaWorker.synth(lang, configForLang(lang), clean);
    if (!samples || samples.length === 0) {
        throw new Error('tts produced no audio');
    }
    const processed = applyEdgeFades(normalizePeak(samples, 0.95), sampleRate);
    return encodeWAV(processed, sampleRate);
}

/** Clean + synthesize text, returning a base64-encoded WAV (for the renderer/HTTP path). */
export async function synthesizeSpeech(text: string): Promise<string> {
    return (await synthesizeSpeechWav(text)).toString('base64');
}

/** True when on-device speech can run and at least one voice model is on disk. */
export async function canSynthesizeNow(): Promise<boolean> {
    return (await isSherpaAvailable()) && anyModelPresent();
}

/** Clean + split text into sentence-sized chunks for streaming synthesis. */
export function splitSpeechText(text: string): string[] {
    return splitSpeechSentences(text);
}

/** Background-download models for the languages present in `text`, but only if already on disk. */
export function prewarm(text: string): void {
    const langs = new Set<SpeechLang>();
    for (const chunk of splitSpeechSentences(text)) {
        langs.add(dominantSpeechLang(chunk) as SpeechLang);
    }
    for (const lang of langs) {
        if (!ttsModelPresentForLang(lang)) {
            continue; // let the click trigger the download
        }
        ensureReadyForLang(lang).catch(err => {
            console.warn(`[tts] prewarm ${lang} failed:`, err instanceof Error ? err.message : err);
        });
    }
}

/**
 * Force the model for `lang` to be present, downloading it if needed. Used when
 * the user enables an auto-speak toggle so the first reply isn't blocked on a
 * silent multi-hundred-MB download. Emits a model-error event on failure.
 */
export async function ensureModel(lang: SpeechLang): Promise<void> {
    try {
        await ensureReadyForLang(lang);
    } catch (err) {
        ttsEvents.emit('model-error', { lang, message: err instanceof Error ? err.message : String(err) });
        throw err;
    }
}

/** Delete the on-disk model for a language so it can be re-downloaded. */
export function deleteModel(lang: SpeechLang): void {
    removeModelForLang(lang);
    ready.delete(lang);
}

export function getModelStatus(): TtsModelStatus {
    return {
        zh: ttsModelPresentForLang('zh'),
        en: ttsModelPresentForLang('en'),
    };
}

export function anyModelPresent(): boolean {
    return meloModelPresent(defaultMeloPaths()) || kokoroModelPresent(defaultKokoroPaths());
}
