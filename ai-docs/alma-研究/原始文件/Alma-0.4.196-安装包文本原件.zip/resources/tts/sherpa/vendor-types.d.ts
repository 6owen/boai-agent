declare module 'unbzip2-stream' {
    import { Transform } from 'stream';
    function unbzip2Stream(): Transform;
    export = unbzip2Stream;
}

declare module 'sherpa-onnx-node' {
    // Minimal surface; the full addon API is documented in the package's types.js.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sherpa: any;
    export = sherpa;
}
