/**
 * On-device TTS model assets: file-path layout, lazy download from mirrors,
 * SHA-256 verification, and tar.bz2 extraction.
 *
 * TypeScript port of `bundled_tts.go`. Two models are supported:
 *   - MeloTTS (vits, zh_en) for Chinese / mixed text   -> lang "zh"
 *   - Kokoro (en) for pure-English text                -> lang "en"
 *
 * Models download to `~/.config/alma/tts/sherpa/` on first use.
 */

import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import * as crypto from 'crypto';
import { createWriteStream } from 'fs';
import { spawn } from 'child_process';
import { pipeline } from 'stream/promises';
import * as tar from 'tar';
import unbzip2 from 'unbzip2-stream';

export type SpeechLang = 'zh' | 'en';

export interface DownloadProgress {
    (asset: string, downloaded: number, total: number, bytesPerSec: number): void;
}

const MELO_DIR_NAME = 'vits-melo-tts-zh_en';
const KOKORO_DIR_NAME = 'kokoro-en-v0_19';

const MELO_MIRROR_URLS = [
    'https://release.yansu.app/sherpa/tts/vits-melo-tts-zh_en.tar.bz2',
    'https://model-assets.yansu.app/sherpa/tts/vits-melo-tts-zh_en.tar.bz2',
    'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-melo-tts-zh_en.tar.bz2',
];
const SHA256_MELO_ARCHIVE = 'e58351ed7149f290a54534538badd4077cdbe6fddc964b24d0bee870415d1514';
const ENV_MELO_URL = 'ALMA_SHERPA_TTS_MELO_URL';

const KOKORO_MIRROR_URLS = [
    'https://release.yansu.app/sherpa/tts/kokoro-en-v0_19.tar.bz2',
    'https://model-assets.yansu.app/sherpa/tts/kokoro-en-v0_19.tar.bz2',
    'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-en-v0_19.tar.bz2',
];
const SHA256_KOKORO_ARCHIVE = '912804855a04745fa77a30be545b3f9a5d15c4d66db00b88cbcd4921df605ac7';
const ENV_KOKORO_URL = 'ALMA_SHERPA_TTS_KOKORO_URL';

export interface MeloPaths {
    root: string;
    modelDir: string;
    model: string;
    lexicon: string;
    tokens: string;
    phoneFst: string;
    dateFst: string;
    numberFst: string;
}

export interface KokoroPaths {
    root: string;
    modelDir: string;
    model: string;
    voices: string;
    tokens: string;
    dataDir: string;
}

function ttsRoot(): string {
    return path.join(os.homedir(), '.config', 'alma', 'tts', 'sherpa');
}

export function defaultMeloPaths(): MeloPaths {
    const root = ttsRoot();
    const md = path.join(root, MELO_DIR_NAME);
    return {
        root,
        modelDir: md,
        model: path.join(md, 'model.onnx'),
        lexicon: path.join(md, 'lexicon.txt'),
        tokens: path.join(md, 'tokens.txt'),
        phoneFst: path.join(md, 'phone.fst'),
        dateFst: path.join(md, 'date.fst'),
        numberFst: path.join(md, 'number.fst'),
    };
}

export function defaultKokoroPaths(): KokoroPaths {
    const root = ttsRoot();
    const md = path.join(root, KOKORO_DIR_NAME);
    return {
        root,
        modelDir: md,
        model: path.join(md, 'model.onnx'),
        voices: path.join(md, 'voices.bin'),
        tokens: path.join(md, 'tokens.txt'),
        dataDir: path.join(md, 'espeak-ng-data'),
    };
}

export function fileExistsAndNonEmpty(p: string): boolean {
    try {
        return fs.statSync(p).size > 0;
    } catch {
        return false;
    }
}

export function meloModelPresent(p: MeloPaths): boolean {
    return fileExistsAndNonEmpty(p.model) && fileExistsAndNonEmpty(p.lexicon) && fileExistsAndNonEmpty(p.tokens);
}

export function kokoroModelPresent(p: KokoroPaths): boolean {
    return fileExistsAndNonEmpty(p.model) && fileExistsAndNonEmpty(p.voices) && fileExistsAndNonEmpty(p.tokens);
}

export function ttsModelPresentForLang(lang: SpeechLang): boolean {
    return lang === 'en' ? kokoroModelPresent(defaultKokoroPaths()) : meloModelPresent(defaultMeloPaths());
}

/** Delete the on-disk model directory for a language (so it can be re-downloaded). */
export function removeModelForLang(lang: SpeechLang): void {
    const dir = lang === 'en' ? defaultKokoroPaths().modelDir : defaultMeloPaths().modelDir;
    fs.rmSync(dir, { recursive: true, force: true });
}

function urlsForAsset(envVar: string, mirrors: string[]): { urls: string[]; override: boolean } {
    const override = process.env[envVar];
    if (override && override.trim() !== '') {
        return { urls: [override.trim()], override: true };
    }
    return { urls: mirrors, override: false };
}

async function downloadAsset(
    asset: string,
    url: string,
    destPath: string,
    expectSha: string,
    progress?: DownloadProgress,
    signal?: AbortSignal
): Promise<void> {
    const res = await fetch(url, { signal });
    if (!res.ok || !res.body) {
        throw new Error(`HTTP ${res.status} for ${url}`);
    }
    const total = Number(res.headers.get('content-length') ?? 0);
    const tmpPath = destPath + '.part';
    const out = createWriteStream(tmpPath);
    const hash = crypto.createHash('sha256');

    let downloaded = 0;
    const startedAt = Date.now();
    let lastEmit = 0;

    try {
        const reader = res.body.getReader();
        for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            if (signal?.aborted) {
                throw new Error('aborted');
            }
            const chunk = Buffer.from(value);
            hash.update(chunk);
            downloaded += chunk.length;
            if (!out.write(chunk)) {
                await new Promise<void>(resolve => out.once('drain', resolve));
            }
            const now = Date.now();
            if (progress && now - lastEmit >= 200) {
                lastEmit = now;
                const elapsed = (now - startedAt) / 1000;
                const bytesPerSec = elapsed > 0 ? downloaded / elapsed : 0;
                progress(asset, downloaded, total, bytesPerSec);
            }
        }
        await new Promise<void>((resolve, reject) => {
            out.end((err?: Error | null) => (err ? reject(err) : resolve()));
        });
    } catch (err) {
        out.destroy();
        try {
            fs.rmSync(tmpPath, { force: true });
        } catch {
            // ignore
        }
        throw err;
    }

    if (expectSha) {
        const got = hash.digest('hex');
        if (got !== expectSha) {
            fs.rmSync(tmpPath, { force: true });
            throw new Error(`sha256 mismatch for ${asset}: expected ${expectSha}, got ${got}`);
        }
    }
    fs.renameSync(tmpPath, destPath);
    if (progress) {
        progress(asset, downloaded, total || downloaded, 0);
    }
}

async function extractTarBz2(archivePath: string, destRoot: string): Promise<void> {
    // Prefer the system `tar` (bsdtar on macOS/Windows, GNU tar on Linux) which
    // autodetects bzip2 and runs in a SEPARATE PROCESS — so decompressing a
    // multi-hundred-MB archive never blocks the Electron main thread. Fall back
    // to the pure-JS stream path if spawning tar fails.
    try {
        await new Promise<void>((resolve, reject) => {
            const child = spawn('tar', ['-xf', archivePath, '-C', destRoot], { stdio: 'ignore' });
            child.on('error', reject);
            child.on('close', code => (code === 0 ? resolve() : reject(new Error(`tar exited with code ${code}`))));
        });
        return;
    } catch (err) {
        console.warn('[tts] system tar extraction failed, falling back to JS:', err instanceof Error ? err.message : err);
    }
    await pipeline(fs.createReadStream(archivePath), unbzip2(), tar.x({ cwd: destRoot }));
}

interface AssetSpec {
    dirName: string;
    mirrors: string[];
    sha256: string;
    envVar: string;
    root: string;
    present: () => boolean;
}

async function ensureAssets(spec: AssetSpec, progress?: DownloadProgress, signal?: AbortSignal): Promise<void> {
    if (spec.present()) {
        return;
    }
    fs.mkdirSync(spec.root, { recursive: true });

    const { urls, override } = urlsForAsset(spec.envVar, spec.mirrors);
    const expectSha = override ? '' : spec.sha256;
    const archivePath = path.join(spec.root, spec.dirName + '.tar.bz2');
    const assetName = `tts/${spec.dirName}.tar.bz2`;

    let lastErr: unknown;
    let downloaded = false;
    for (const url of urls) {
        try {
            await downloadAsset(assetName, url, archivePath, expectSha, progress, signal);
            downloaded = true;
            break;
        } catch (err) {
            lastErr = err;
            console.warn(`[tts] download from ${url} failed:`, err instanceof Error ? err.message : err);
        }
    }
    if (!downloaded) {
        throw new Error(`download ${spec.dirName}: ${lastErr instanceof Error ? lastErr.message : String(lastErr)}`);
    }

    try {
        await extractTarBz2(archivePath, spec.root);
    } finally {
        try {
            fs.rmSync(archivePath, { force: true });
        } catch {
            // ignore
        }
    }
    if (!spec.present()) {
        throw new Error(`${spec.dirName}: model files missing after extraction`);
    }
    console.log(`[tts] ${spec.dirName} model extracted to ${spec.root}`);
}

export async function ensureMeloAssets(paths: MeloPaths, progress?: DownloadProgress, signal?: AbortSignal): Promise<void> {
    await ensureAssets(
        {
            dirName: MELO_DIR_NAME,
            mirrors: MELO_MIRROR_URLS,
            sha256: SHA256_MELO_ARCHIVE,
            envVar: ENV_MELO_URL,
            root: paths.root,
            present: () => meloModelPresent(paths),
        },
        progress,
        signal
    );
}

export async function ensureKokoroAssets(paths: KokoroPaths, progress?: DownloadProgress, signal?: AbortSignal): Promise<void> {
    await ensureAssets(
        {
            dirName: KOKORO_DIR_NAME,
            mirrors: KOKORO_MIRROR_URLS,
            sha256: SHA256_KOKORO_ARCHIVE,
            envVar: ENV_KOKORO_URL,
            root: paths.root,
            present: () => kokoroModelPresent(paths),
        },
        progress,
        signal
    );
}
