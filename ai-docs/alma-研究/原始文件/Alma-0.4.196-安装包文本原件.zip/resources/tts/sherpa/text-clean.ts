/**
 * Text cleaning + sentence splitting for on-device speech synthesis.
 *
 * Faithful TypeScript port of `tts_text_clean.go` from the reference
 * implementation. Strips markdown/emoji/HTML, spells out acronyms, fixes CJK
 * spacing quirks that derail MeloTTS, and splits cleaned text into
 * sentence-sized chunks for gapless streaming playback.
 */

/** Returns "en" only for text with Latin letters and no Han characters; "zh" otherwise. */
export function dominantSpeechLang(s: string): string {
    let hasLatin = false;
    for (const r of s) {
        if (/\p{Script=Han}/u.test(r)) {
            return 'zh';
        }
        if ((r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z')) {
            hasLatin = true;
        }
    }
    return hasLatin ? 'en' : 'zh';
}

const reFencedCode = /```[\s\S]*?```/g;
const reInlineCode = /`([^`]*)`/g;
const reImage = /!\[[^\]]*\]\([^)]*\)/g;
const reLink = /\[([^\]]+)\]\([^)]*\)/g;
const reHeadingMark = /^[ \t]{0,3}#{1,6}[ \t]+/gm;
const reBlockquote = /^[ \t]{0,3}>[ \t]?/gm;
const reListMarker = /^[ \t]*([-*+]|\d+[.)])[ \t]+/gm;
const reTableDivider = /^[ \t]*\|?[ \t:|-]+\|[ \t:|-]*$/gm;
const reEmphasis = /(\*\*|__|\*|_|~~)/g;
const reHTMLTag = /<[^>]+>/g;
const reBareURL = /https?:\/\/\S+/g;
const reMultiNewline = /\n{3,}/g;
const reMultiSpace = /[ \t]{2,}/g;
const reHanSpaceHan = /(\p{Script=Han})[ \t]+(\p{Script=Han})/gu;
// Emoji / pictograph ranges that TTS can't pronounce and that derail synthesis.
// The class intentionally includes the ZWJ and variation selectors so emoji
// sequences are stripped whole; the no-misleading-character-class rule flags
// those combining marks, but with the `u` flag the behavior is correct.
const reEmoji =
    // eslint-disable-next-line no-misleading-character-class
    /[\u{1F000}-\u{1FFFF}\u{2190}-\u{21FF}\u{2300}-\u{23FF}\u{2460}-\u{24FF}\u{2500}-\u{25FF}\u{2600}-\u{27BF}\u{2900}-\u{297F}\u{2B00}-\u{2BFF}\u{FE00}-\u{FE0F}\u{200D}\u{20E3}\u{2022}\u{2023}\u{2043}\u{2122}\u{2139}\u{3030}\u{303D}\u{3297}\u{3299}\u{00A9}\u{00AE}]/gu;
const reBracketGroup = /[（(][^（()）]*[)）]/g;
const reQuotes = /["“”„「」『』《》〈〉]/g;
const reAcronym = /[A-Z]{2,}/g;
const reDashRun = /[—―]+/g;
const reInterpunct = /[·・]/g;
const reNumericRange = /(\d)\s*[—―～〜]\s*(\d)/g;
const reWaveDash = /[～〜]/g;
const reSpaceAfterCJKPunct = /([，、；：。！？])[ \t]+/g;

const secondarySplitRe = /[^，、；：,;—…]*[，、；：,;—…]|[^，、；：,;—…]+$/g;

const TTS_MAX_CHUNK_RUNES_ZH = 30;
const TTS_MAX_CHUNK_RUNES_EN = 80;

function hasSpeechContent(s: string): boolean {
    for (const r of s) {
        if (/\p{Script=Han}/u.test(r) || (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9')) {
            return true;
        }
    }
    return false;
}

function stripDecorativeBrackets(s: string): string {
    return s.replace(reBracketGroup, m => (hasSpeechContent(m) ? m : ''));
}

function collapseHanSpaces(s: string): string {
    for (;;) {
        const next = s.replace(reHanSpaceHan, '$1$2');
        if (next === s) {
            return s;
        }
        s = next;
    }
}

function expandAcronyms(s: string): string {
    return s.replace(reAcronym, m => ' ' + m.toLowerCase().split('').join(' ') + ' ');
}

function normalizeSpeechSeparators(s: string): string {
    let rangeWord = '到';
    let pause = '，';
    if (dominantSpeechLang(s) === 'en') {
        rangeWord = ' to ';
        pause = ', ';
    }
    s = s.replace(reNumericRange, `$1${rangeWord}$2`);
    s = s.replace(reDashRun, pause);
    s = s.replace(reInterpunct, pause);
    return s.replace(reWaveDash, '');
}

function isCloser(r: string): boolean {
    switch (r) {
        case '"':
        case "'":
        case '”':
        case '’':
        case '」':
        case '』':
        case ')':
        case '）':
        case '】':
            return true;
    }
    return false;
}

function splitIntoSentences(s: string): string[] {
    const runes = Array.from(s);
    const out: string[] = [];
    let start = 0;
    for (let i = 0; i < runes.length; i++) {
        const r = runes[i];
        let end = false;
        switch (r) {
            case '。':
            case '！':
            case '？':
            case '!':
            case '?':
            case '\n':
                end = true;
                break;
            case '.': {
                const next = i + 1;
                const atBoundary = next >= runes.length || runes[next] === ' ' || isCloser(runes[next]);
                const prevDigit = i > 0 && runes[i - 1] >= '0' && runes[i - 1] <= '9';
                const nextDigit = next < runes.length && runes[next] >= '0' && runes[next] <= '9';
                end = atBoundary && !prevDigit && !nextDigit;
                break;
            }
        }
        if (end) {
            let j = i + 1;
            while (j < runes.length && isCloser(runes[j])) {
                j++;
            }
            out.push(runes.slice(start, j).join(''));
            start = j;
            i = j - 1;
        }
    }
    if (start < runes.length) {
        out.push(runes.slice(start).join(''));
    }
    return out;
}

function hardSplitAtWord(s: string, max: number): string[] {
    let runes = Array.from(s);
    const out: string[] = [];
    while (runes.length > max) {
        let cut = max;
        for (let i = max; i > Math.floor(max / 2); i--) {
            if (runes[i] === ' ') {
                cut = i;
                break;
            }
        }
        const piece = runes.slice(0, cut).join('').trim();
        if (piece !== '') {
            out.push(piece);
        }
        runes = runes.slice(cut);
    }
    const rest = runes.join('').trim();
    if (rest !== '') {
        out.push(rest);
    }
    return out;
}

function splitLongChunk(s: string, max: number): string[] {
    if (Array.from(s).length <= max) {
        return [s];
    }
    const out: string[] = [];
    let buf = '';
    let bufLen = 0;
    const flush = () => {
        if (bufLen > 0) {
            out.push(buf.trim());
            buf = '';
            bufLen = 0;
        }
    };
    const parts = s.match(secondarySplitRe) ?? [];
    for (let part of parts) {
        part = part.trim();
        if (part === '') {
            continue;
        }
        const partLen = Array.from(part).length;
        if (partLen > max) {
            flush();
            out.push(...hardSplitAtWord(part, max));
            continue;
        }
        if (bufLen + partLen > max) {
            flush();
        }
        if (buf.length > 0) {
            buf += ' ';
        }
        buf += part;
        bufLen += partLen;
    }
    flush();
    return out;
}

/** Strip markdown, emoji, HTML and other non-speech noise from text. */
export function stripMarkdownForSpeech(md: string): string {
    let s = md;
    s = s.replace(reFencedCode, ' ');
    s = s.replace(reImage, ' ');
    s = s.replace(reLink, '$1');
    s = s.replace(reInlineCode, '$1');
    s = s.replace(/`/g, '');
    s = s.replace(reTableDivider, '');
    s = s.replace(reHeadingMark, '');
    s = s.replace(reBlockquote, '');
    s = s.replace(reListMarker, '');
    s = s.replace(reEmphasis, '');
    s = s.replace(reHTMLTag, ' ');
    s = s.replace(reBareURL, ' ');
    s = s.replace(reEmoji, '');
    s = stripDecorativeBrackets(s);
    s = s.replace(reQuotes, '');
    s = normalizeSpeechSeparators(s);
    s = expandAcronyms(s);
    s = s.replace(/\|/g, ' ');

    s = s.replace(reMultiSpace, ' ');
    s = collapseHanSpaces(s);
    s = s.replace(reMultiNewline, '\n\n');

    const lines = s.split('\n').map(ln => ln.replace(/[ \t]+$/, ''));
    return lines.join('\n').trim();
}

/** Clean and split text into sentence-sized chunks for streaming synthesis. */
export function splitSpeechSentences(md: string): string[] {
    const clean = stripMarkdownForSpeech(md);
    if (clean === '') {
        return [];
    }
    const out: string[] = [];
    for (let sentence of splitIntoSentences(clean)) {
        sentence = sentence.trim();
        if (sentence === '') {
            continue;
        }
        const max = dominantSpeechLang(sentence) === 'en' ? TTS_MAX_CHUNK_RUNES_EN : TTS_MAX_CHUNK_RUNES_ZH;
        for (let chunk of splitLongChunk(sentence, max)) {
            chunk = chunk.trim();
            if (chunk === '') {
                continue;
            }
            chunk = collapseHanSpaces(chunk.replace(reSpaceAfterCJKPunct, '$1'));
            if (!hasSpeechContent(chunk) && out.length > 0) {
                out[out.length - 1] = out[out.length - 1] + ' ' + chunk;
                continue;
            }
            out.push(chunk);
        }
    }
    return out;
}
