/**
 * Sherpa-onnx TTS worker — runs under the bundled **bun** runtime, NOT Electron.
 *
 * Why a separate process: Electron's V8 build forbids "external" ArrayBuffers,
 * so the Float32Array that sherpa-onnx returns from generate() throws
 * "External buffers are not allowed" in the main process. bun uses
 * JavaScriptCore (no such restriction), so synthesis runs here and the raw PCM
 * is shipped back to the main process as a base64 string (which crosses the
 * process boundary safely). Running in a child process also keeps the
 * CPU-heavy synthesis off the Electron main thread.
 *
 * Protocol: newline-delimited JSON on stdin/stdout.
 *   in : { id, lang, config, text }
 *   out: { id, ok: true, sampleRate, pcm }   // pcm = base64 of little-endian Float32
 *        { id, ok: false, error }
 * The sherpa-onnx-node entry path is passed via the SHERPA_ENTRY env var
 * (resolving it from inside this file's node_modules is unreliable once packed).
 */

'use strict';
/* eslint-env node */
/* eslint-disable @typescript-eslint/no-var-requires */

const readline = require('readline');

let OfflineTts = null;
function loadSherpa() {
    if (OfflineTts) return OfflineTts;
    const entry = process.env.SHERPA_ENTRY;
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require(entry || 'sherpa-onnx-node');
    OfflineTts = mod.OfflineTts || (mod.default && mod.default.OfflineTts);
    if (!OfflineTts) throw new Error('sherpa-onnx-node: OfflineTts export not found');
    return OfflineTts;
}

const engines = new Map(); // lang -> OfflineTts instance

function engineFor(lang, config) {
    let engine = engines.get(lang);
    if (!engine) {
        const Ctor = loadSherpa();
        engine = new Ctor(config);
        engines.set(lang, engine);
    }
    return engine;
}

function send(obj) {
    process.stdout.write(JSON.stringify(obj) + '\n');
}

const rl = readline.createInterface({ input: process.stdin });
rl.on('line', line => {
    line = line.trim();
    if (!line) return;
    let req;
    try {
        req = JSON.parse(line);
    } catch {
        return;
    }
    const { id, lang, config, text } = req;
    try {
        const engine = engineFor(lang, config);
        const audio = engine.generate({ text, sid: 0, speed: 1.0 });
        if (!audio || !audio.samples || audio.samples.length === 0) {
            throw new Error('tts produced no audio');
        }
        const samples = audio.samples; // Float32Array
        const pcm = Buffer.from(samples.buffer, samples.byteOffset, samples.byteLength).toString('base64');
        send({ id, ok: true, sampleRate: audio.sampleRate, pcm });
    } catch (err) {
        send({ id, ok: false, error: err && err.message ? err.message : String(err) });
    }
});

process.on('uncaughtException', err => {
    try {
        send({ id: -1, ok: false, error: 'worker uncaught: ' + (err && err.message ? err.message : String(err)) });
    } catch {
        // ignore
    }
});
