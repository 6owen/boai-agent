/**
 * Main-process client for the bun-backed sherpa TTS worker (see tts-worker.cjs).
 *
 * Spawns a long-lived bun child process, proxies synthesis requests over
 * newline-delimited JSON, and decodes the returned base64 PCM into a normal
 * (V8-owned) Float32Array — which is safe to use inside Electron, unlike the
 * external buffer sherpa would hand back if run in-process.
 */

import * as fs from 'fs';
import * as path from 'path';
import * as readline from 'readline';
import { spawn, ChildProcessWithoutNullStreams } from 'child_process';
import { app } from 'electron';
import { resolveBunPath } from '../../bunPath';

export interface SynthResult {
    sampleRate: number;
    samples: Float32Array;
}

interface Pending {
    resolve: (r: SynthResult) => void;
    reject: (e: Error) => void;
    timer: NodeJS.Timeout;
}

/** Absolute path to the worker script (bundled to resources in packaged builds). */
function workerScriptPath(): string | null {
    const candidates = [
        process.resourcesPath ? path.join(process.resourcesPath, 'tts', 'sherpa', 'tts-worker.cjs') : '',
        path.join(app.getAppPath(), 'electron', 'tts', 'sherpa', 'tts-worker.cjs'),
        path.join(app.getAppPath(), '..', 'electron', 'tts', 'sherpa', 'tts-worker.cjs'),
    ].filter(Boolean);
    return candidates.find(p => fs.existsSync(p)) ?? null;
}

/** Absolute path to sherpa-onnx-node's entry, passed to the worker via env. */
function sherpaEntryPath(): string | null {
    const rel = path.join('node_modules', 'sherpa-onnx-node', 'sherpa-onnx.js');
    const appPath = app.getAppPath();
    // The worker runs under bun, which has NO asar-aware fs patch — so it can
    // never `require()` a path inside app.asar. In packaged builds sherpa-onnx-node
    // is unpacked (see electron-builder.yml asarUnpack), so we must hand the worker
    // the real on-disk app.asar.unpacked path. Electron's own fs.existsSync resolves
    // an app.asar/... path as "exists" even when unpacked, which is exactly the trap
    // that shipped the broken in-asar path to bun — so never offer that candidate here.
    const candidates = app.isPackaged
        ? [
              appPath.includes('app.asar') ? path.join(appPath.replace('app.asar', 'app.asar.unpacked'), rel) : '',
              process.resourcesPath ? path.join(process.resourcesPath, 'app.asar.unpacked', rel) : '',
          ]
        : [path.join(appPath, rel)];
    return candidates.filter(Boolean).find(p => fs.existsSync(p)) ?? null;
}

const SYNTH_TIMEOUT_MS = 60_000;

class SherpaWorkerClient {
    private child: ChildProcessWithoutNullStreams | null = null;
    private rl: readline.Interface | null = null;
    private nextId = 1;
    private pending = new Map<number, Pending>();

    available(): boolean {
        return !!resolveBunPath() && !!workerScriptPath() && !!sherpaEntryPath();
    }

    private ensureChild(): ChildProcessWithoutNullStreams {
        if (this.child && !this.child.killed) return this.child;

        const bun = resolveBunPath();
        const script = workerScriptPath();
        const entry = sherpaEntryPath();
        if (!bun || !script || !entry) {
            throw new Error('sherpa TTS worker unavailable (missing bun, worker script, or sherpa-onnx-node)');
        }

        const child = spawn(bun, [script], {
            stdio: ['pipe', 'pipe', 'pipe'],
            env: { ...process.env, SHERPA_ENTRY: entry },
        });
        this.child = child;

        this.rl = readline.createInterface({ input: child.stdout });
        this.rl.on('line', line => this.onLine(line));
        child.stderr.on('data', d => console.warn('[tts-worker]', String(d).trim()));
        child.on('exit', code => {
            const err = new Error(`sherpa TTS worker exited (code ${code})`);
            for (const p of this.pending.values()) {
                clearTimeout(p.timer);
                p.reject(err);
            }
            this.pending.clear();
            this.rl?.close();
            this.rl = null;
            this.child = null;
        });
        child.on('error', e => console.error('[tts-worker] spawn error:', e));
        return child;
    }

    private onLine(line: string): void {
        line = line.trim();
        if (!line) return;
        let msg: { id: number; ok: boolean; sampleRate?: number; pcm?: string; error?: string };
        try {
            msg = JSON.parse(line);
        } catch {
            return;
        }
        const p = this.pending.get(msg.id);
        if (!p) return;
        this.pending.delete(msg.id);
        clearTimeout(p.timer);
        if (msg.ok && msg.pcm != null && msg.sampleRate != null) {
            const buf = Buffer.from(msg.pcm, 'base64');
            // Copy into a fresh, 0-offset ArrayBuffer so the Float32Array is V8-owned.
            const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
            p.resolve({ sampleRate: msg.sampleRate, samples: new Float32Array(ab) });
        } else {
            p.reject(new Error(msg.error || 'sherpa worker error'));
        }
    }

    /**
     * Synthesize one chunk. `config` is the sherpa OfflineTts config (the worker
     * builds + caches the engine per `lang` on first use).
     */
    synth(lang: string, config: unknown, text: string): Promise<SynthResult> {
        return new Promise<SynthResult>((resolve, reject) => {
            let child: ChildProcessWithoutNullStreams;
            try {
                child = this.ensureChild();
            } catch (e) {
                reject(e instanceof Error ? e : new Error(String(e)));
                return;
            }
            const id = this.nextId++;
            const timer = setTimeout(() => {
                this.pending.delete(id);
                reject(new Error('sherpa synthesis timed out'));
            }, SYNTH_TIMEOUT_MS);
            this.pending.set(id, { resolve, reject, timer });
            // Config is small (file paths); the worker builds + caches the engine
            // per lang on first sight and ignores it thereafter.
            child.stdin.write(JSON.stringify({ id, lang, config, text }) + '\n');
        });
    }

    dispose(): void {
        if (this.child && !this.child.killed) {
            this.child.kill();
        }
    }
}

export const sherpaWorker = new SherpaWorkerClient();
