/**
 * Audio post-processing + WAV encoding for on-device speech synthesis.
 *
 * TypeScript port of `tts_wav.go`. Operates on the Float32 sample buffers that
 * sherpa-onnx produces, normalizes peak amplitude, fades the edges to avoid
 * clicks/pops, and encodes a 16-bit mono PCM WAV.
 */

/** Scale samples so the peak amplitude reaches `target` (gain capped at 8x). Mutates in place. */
export function normalizePeak(samples: Float32Array, target: number): Float32Array {
    let peak = 0;
    for (let i = 0; i < samples.length; i++) {
        const v = samples[i] < 0 ? -samples[i] : samples[i];
        if (v > peak) {
            peak = v;
        }
    }
    if (peak === 0) {
        return samples;
    }
    let gain = target / peak;
    if (gain > 8) {
        gain = 8;
    }
    if (gain > 0.99 && gain < 1.01) {
        return samples;
    }
    for (let i = 0; i < samples.length; i++) {
        samples[i] *= gain;
    }
    return samples;
}

/** Linearly fade the first/last ~12ms to prevent clicks at clip boundaries. Mutates in place. */
export function applyEdgeFades(samples: Float32Array, sampleRate: number): Float32Array {
    let fade = Math.floor((sampleRate * 12) / 1000);
    if (fade * 2 > samples.length) {
        fade = Math.floor(samples.length / 2);
    }
    for (let i = 0; i < fade; i++) {
        const gain = i / fade;
        samples[i] *= gain;
        samples[samples.length - 1 - i] *= gain;
    }
    return samples;
}

/** Encode Float32 [-1,1] samples as a 16-bit mono PCM WAV buffer. */
export function encodeWAV(samples: Float32Array, sampleRate: number): Buffer {
    const dataLen = samples.length * 2;
    const buf = Buffer.alloc(44 + dataLen);
    buf.write('RIFF', 0, 'ascii');
    buf.writeUInt32LE(36 + dataLen, 4);
    buf.write('WAVE', 8, 'ascii');
    buf.write('fmt ', 12, 'ascii');
    buf.writeUInt32LE(16, 16); // fmt chunk size
    buf.writeUInt16LE(1, 20); // PCM
    buf.writeUInt16LE(1, 22); // mono
    buf.writeUInt32LE(sampleRate, 24);
    buf.writeUInt32LE(sampleRate * 2, 28); // byte rate
    buf.writeUInt16LE(2, 32); // block align
    buf.writeUInt16LE(16, 34); // bits per sample
    buf.write('data', 36, 'ascii');
    buf.writeUInt32LE(dataLen, 40);

    let offset = 44;
    for (let i = 0; i < samples.length; i++) {
        let sample = samples[i];
        if (sample > 1) {
            sample = 1;
        } else if (sample < -1) {
            sample = -1;
        }
        buf.writeInt16LE((sample * 32767) | 0, offset);
        offset += 2;
    }
    return buf;
}
