#!/usr/bin/env python3
"""
Simple CLI wrapper for Qwen3-TTS — used by Alma for voice generation.

Usage:
  python3 tts_cli.py --text "你好世界" --output /tmp/hello.wav [--voice Vivian] [--emotion "cheerful"] [--speed 1.0]
  python3 tts_cli.py --text "Hello world" --output /tmp/hello.wav --voice Chelsie
"""

import argparse
import os
import sys
import shutil
import warnings
import gc

os.environ["TOKENIZERS_PARALLELISM"] = "false"
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

DEFAULT_MODELS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
MODELS_DIR = DEFAULT_MODELS_DIR  # May be overridden by --models-dir


def get_model_path(folder_name):
    full_path = os.path.join(MODELS_DIR, folder_name)
    if not os.path.exists(full_path):
        return None
    snapshots_dir = os.path.join(full_path, "snapshots")
    if os.path.exists(snapshots_dir):
        subfolders = [f for f in os.listdir(snapshots_dir) if not f.startswith('.')]
        if subfolders:
            return os.path.join(snapshots_dir, subfolders[0])
    return full_path


def main():
    parser = argparse.ArgumentParser(description="Qwen3-TTS CLI")
    parser.add_argument("--text", required=True, help="Text to speak")
    parser.add_argument("--output", required=True, help="Output WAV file path")
    parser.add_argument("--voice", default="Vivian", help="Voice name (default: Vivian for Chinese)")
    parser.add_argument("--emotion", default="", help="Emotion/style instruction (e.g. 'cheerful', 'sad and slow')")
    parser.add_argument("--speed", type=float, default=1.0, help="Speed multiplier (default: 1.0)")
    parser.add_argument("--model", default="CustomVoice-1.7B", help="Model folder name")
    parser.add_argument("--models-dir", default=None, help="Override models directory path")
    args = parser.parse_args()

    global MODELS_DIR
    if args.models_dir:
        MODELS_DIR = args.models_dir

    # Auto-download model if not found
    model_path = get_model_path(args.model)
    if not model_path:
        print(f"Model not found locally, downloading...", file=sys.stderr)
        try:
            os.makedirs(MODELS_DIR, exist_ok=True)
            from huggingface_hub import snapshot_download
            target = os.path.join(MODELS_DIR, args.model)
            snapshot_download(
                repo_id="mlx-community/Qwen3-TTS-12Hz-1.7B-CustomVoice-8bit",
                local_dir=target,
                local_dir_use_symlinks=False,
            )

            # Basic integrity check: ensure we have at least one weight file either at the model root
            # OR under known subfolders (some layouts place weights under speech_tokenizer/).
            def _has_weight_files(p):
                for root, _, files in os.walk(p):
                    # keep it shallow-ish to avoid scanning huge caches
                    rel = os.path.relpath(root, p)
                    if rel != "." and rel.count(os.sep) >= 3:
                        continue
                    for name in files:
                        if name.endswith((".safetensors", ".npz", ".bin")):
                            return True
                return False

            if os.path.isdir(target) and not _has_weight_files(target):
                # Sometimes partial downloads can leave only non-weight assets behind.
                # Remove and retry once.
                shutil.rmtree(target, ignore_errors=True)
                snapshot_download(
                    repo_id="mlx-community/Qwen3-TTS-12Hz-1.7B-CustomVoice-8bit",
                    local_dir=target,
                    local_dir_use_symlinks=False,
                )
            model_path = get_model_path(args.model)
        except Exception as e:
            print(f"Error downloading model: {e}", file=sys.stderr)
            sys.exit(1)
    if not model_path:
        print(f"Error: Model not found at {MODELS_DIR}/{args.model}", file=sys.stderr)
        sys.exit(1)

    try:
        from mlx_audio.tts.utils import load_model
        from mlx_audio.tts.generate import generate_audio
    except ImportError:
        print("Error: mlx_audio not installed. Run: source .venv/bin/activate && pip install -r requirements.txt", file=sys.stderr)
        sys.exit(1)

    # Build instruct string
    instruct = args.emotion if args.emotion else "Speak naturally"

    # Temp output dir for generate_audio
    temp_dir = f"/tmp/qwen3_tts_{os.getpid()}"
    os.makedirs(temp_dir, exist_ok=True)

    try:
        print(f"Loading model: {args.model}...", file=sys.stderr)
        model = load_model(model_path)

        print(f"Generating: \"{args.text[:50]}...\" voice={args.voice} emotion={instruct}", file=sys.stderr)
        generate_audio(
            model=model,
            text=args.text,
            voice=args.voice,
            instruct=instruct,
            speed=args.speed,
            output_path=temp_dir,
        )

        # Move output to desired path
        source = os.path.join(temp_dir, "audio_000.wav")
        if os.path.exists(source):
            os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
            shutil.move(source, args.output)
            print(args.output)  # Print path to stdout for caller
        else:
            print("Error: No audio generated", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
        gc.collect()


if __name__ == "__main__":
    main()
