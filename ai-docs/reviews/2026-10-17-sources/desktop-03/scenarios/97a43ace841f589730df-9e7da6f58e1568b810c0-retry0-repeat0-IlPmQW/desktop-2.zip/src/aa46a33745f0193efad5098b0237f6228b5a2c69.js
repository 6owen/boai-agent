// Generated from: tests/e2e/features/local-skills.feature
import { test } from "../tests/e2e/steps/local-skills.steps.ts";

test.describe('本机技能管理使用图标导航与会话式列表详情', () => {

  test('首次打开即可发现本机技能并整理分组', async ({ Given, When, Then, localSkills, runtime }) => { 
    await Given('本机已有全局技能和插件但尚未向 BoAI 导入', null, { localSkills, runtime }); 
    await When('从侧栏打开技能管理', null, { runtime }); 
    await Then('会话式两栏显示本机技能来源和正文且没有授予员工权限', null, { localSkills, runtime }); 
    await When('搜索插件技能并加入自己的分组', null, { runtime }); 
    await Then('重启后技能收藏和分组仍可访问', null, { runtime }); 
    await When('通过受管资源兼容接口预览并导入本机技能', null, { localSkills, runtime }); 
    await Then('原文件保持不变且导入副本未自动绑定员工', null, { localSkills, runtime }); 
  });

  test('技能分组沿用会话拖拽并保存整理结果', async ({ Given, When, Then, And, localSkills, runtime }) => { 
    await Given('本机已有全局技能和插件但尚未向 BoAI 导入', null, { localSkills, runtime }); 
    await When('从侧栏打开技能管理', null, { runtime }); 
    await And('收藏两个技能并在原位置编辑分组', null, { runtime }); 
    await Then('分组与技能使用会话落点提示进行排序和跨组移动', null, { runtime }); 
    await And('重启后分组顺序和技能顺序保持且没有新增授权', null, { runtime }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('tests/e2e/features/local-skills.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":7,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":8,"keywordType":"Context","textWithKeyword":"假如本机已有全局技能和插件但尚未向 BoAI 导入","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":9,"keywordType":"Action","textWithKeyword":"当从侧栏打开技能管理","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"那么会话式两栏显示本机技能来源和正文且没有授予员工权限","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":11,"keywordType":"Action","textWithKeyword":"当搜索插件技能并加入自己的分组","stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":12,"keywordType":"Outcome","textWithKeyword":"那么重启后技能收藏和分组仍可访问","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":13,"keywordType":"Action","textWithKeyword":"当通过受管资源兼容接口预览并导入本机技能","stepMatchArguments":[]},{"pwStepLine":13,"gherkinStepLine":14,"keywordType":"Outcome","textWithKeyword":"那么原文件保持不变且导入副本未自动绑定员工","stepMatchArguments":[]}]},
  {"pwTestLine":16,"pickleLine":16,"tags":[],"steps":[{"pwStepLine":17,"gherkinStepLine":17,"keywordType":"Context","textWithKeyword":"假如本机已有全局技能和插件但尚未向 BoAI 导入","stepMatchArguments":[]},{"pwStepLine":18,"gherkinStepLine":18,"keywordType":"Action","textWithKeyword":"当从侧栏打开技能管理","stepMatchArguments":[]},{"pwStepLine":19,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"并且收藏两个技能并在原位置编辑分组","stepMatchArguments":[]},{"pwStepLine":20,"gherkinStepLine":20,"keywordType":"Outcome","textWithKeyword":"那么分组与技能使用会话落点提示进行排序和跨组移动","stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":21,"keywordType":"Outcome","textWithKeyword":"并且重启后分组顺序和技能顺序保持且没有新增授权","stepMatchArguments":[]}]},
]; // bdd-data-end