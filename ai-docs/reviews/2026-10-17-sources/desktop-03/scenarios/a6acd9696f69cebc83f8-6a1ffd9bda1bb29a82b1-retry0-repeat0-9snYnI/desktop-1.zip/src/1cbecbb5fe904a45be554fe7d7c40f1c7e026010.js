// Generated from: tests/e2e/features/sources.feature
import { test } from "../tests/e2e/steps/sources.steps.ts";

test.describe('技能与数据源共用自定义工作区', () => {

  test('本地文件夹绑定员工并与原技能页面共存', { tag: ['@electron', '@sources'] }, async ({ Given, When, Then, runtime, sources }) => { 
    await Given('自定义工作区已有本机技能和文件夹', null, { runtime, sources }); 
    await When('添加并测试本地文件夹然后绑定研究员', null, { runtime, sources }); 
    await Then('技能详情和收藏仍可使用且数据源重启后保留', null, { runtime, sources }); 
    await When('删除已绑定的本地数据源', null, { runtime }); 
    await Then('员工授权已移除而文件夹原件保留', null, { runtime, sources }); 
  });

  test('API数据源保留私有凭据并支持连接测试及停用', { tag: ['@electron', '@sources'] }, async ({ Given, When, Then, runtime, sources }) => { 
    await Given('自定义工作区已有本机技能和文件夹', null, { runtime, sources }); 
    await When('添加使用密钥的本地API数据源并测试连接', null, { runtime, sources }); 
    await Then('密钥未回显且停用和MCP配置均可保存', null, { runtime, sources }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('tests/e2e/features/sources.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":8,"tags":["@electron","@sources"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"假如自定义工作区已有本机技能和文件夹","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":10,"keywordType":"Action","textWithKeyword":"当添加并测试本地文件夹然后绑定研究员","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":11,"keywordType":"Outcome","textWithKeyword":"那么技能详情和收藏仍可使用且数据源重启后保留","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":12,"keywordType":"Action","textWithKeyword":"当删除已绑定的本地数据源","stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":13,"keywordType":"Outcome","textWithKeyword":"那么员工授权已移除而文件夹原件保留","stepMatchArguments":[]}]},
  {"pwTestLine":14,"pickleLine":15,"tags":["@electron","@sources"],"steps":[{"pwStepLine":15,"gherkinStepLine":16,"keywordType":"Context","textWithKeyword":"假如自定义工作区已有本机技能和文件夹","stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"当添加使用密钥的本地API数据源并测试连接","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":18,"keywordType":"Outcome","textWithKeyword":"那么密钥未回显且停用和MCP配置均可保存","stepMatchArguments":[]}]},
]; // bdd-data-end