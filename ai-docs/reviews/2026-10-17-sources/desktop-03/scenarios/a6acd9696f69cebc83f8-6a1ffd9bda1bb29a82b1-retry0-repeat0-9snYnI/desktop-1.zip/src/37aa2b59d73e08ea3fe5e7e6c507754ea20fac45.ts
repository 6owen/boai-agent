/*
 * [INPUT]: Real Electron IPC, isolated skill/folder fixtures and local authenticated HTTP.
 * [OUTPUT]: Integrated navigation, source lifecycle/binding and existing skill favorite flow.
 * [POS]: Desktop source acceptance; no model or external account.
 * [PROTOCOL]: 变化同步 Header 与 steps/.folder.md。
 */
import { expect } from '@playwright/test'
import { createBdd } from 'playwright-bdd'
import { createServer } from 'node:http'
import { mkdir, writeFile, readFile, realpath } from 'node:fs/promises'
import { join } from 'node:path'
import { test as base } from '../support/test'
import { startLocalSkills } from '../support/local-skills'
type State = { folder?: string; id?: string; requests: number }
export const test = base.extend<{ sources: State }>({ sources: async ({}, use) => use({ requests: 0 }) })
const { Given, When, Then } = createBdd(test)
Given('自定义工作区已有本机技能和文件夹', async ({ runtime, sources }) => {
  sources.folder = join(runtime.root, 'project-source'); await mkdir(sources.folder); sources.folder = await realpath(sources.folder); await writeFile(join(sources.folder, 'facts.md'), 'SOURCE_ORIGINAL')
  await startLocalSkills(runtime)
  await runtime.page.getByRole('navigation', { name: '主导航' }).getByRole('button', { name: '自定义', exact: true }).click()
  await expect(runtime.page.getByRole('complementary', { name: '自定义导航' })).toBeVisible()
  await runtime.page.getByRole('complementary', { name: '自定义导航' }).getByRole('button', { name: '数据源', exact: true }).click()
})
When('添加并测试本地文件夹然后绑定研究员', async ({ runtime, sources }) => {
  const page = runtime.page
  await page.getByRole('button', { name: '添加数据源', exact: true }).first().click(); await page.getByRole('menuitem', { name: '本地文件夹', exact: true }).click()
  await page.getByRole('textbox', { name: '名称', exact: true }).fill('项目资料')
  await runtime.app.evaluate(({ dialog }, path) => { dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [path!] }) }, sources.folder)
  await page.getByRole('button', { name: '选择文件夹', exact: true }).click()
  await expect(page.getByRole('textbox', { name: '文件夹路径' })).toHaveValue(sources.folder!)
  await page.getByRole('textbox', { name: '使用说明', exact: true }).fill('读取 facts.md 中的项目事实。')
  await page.getByRole('button', { name: '保存数据源', exact: true }).click()
  await expect(page.getByRole('dialog')).toHaveCount(0)
  sources.id = (await page.evaluate(() => window.boai.request('listDataSources', undefined)))[0].id
  await page.getByRole('button', { name: '测试连接', exact: true }).click(); await expect(page.getByText('连接正常', { exact: true })).toBeVisible()
  await page.getByRole('button', { name: '绑定员工', exact: true }).click()
  await page.getByRole('dialog').getByRole('checkbox', { name: /研究员/ }).check()
  await page.getByRole('button', { name: '保存绑定', exact: true }).click(); await expect(page.getByRole('dialog')).toHaveCount(0)
  await expect.poll(async () => (await page.evaluate(() => window.boai.request('snapshot', undefined))).agents.find(agent => agent.id === 'researcher')?.sourceIds).toEqual([sources.id])
  await runtime.reviewNativeCheckpoint('文件夹详情与员工绑定')
})
Then('技能详情和收藏仍可使用且数据源重启后保留', async ({ runtime, sources }) => {
  const page = runtime.page
  await page.getByRole('button', { name: '技能：agents-sdk', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Agents SDK', exact: true })).toBeVisible()
  await page.getByRole('button', { name: '当前技能操作', exact: true }).click(); await page.getByRole('menuitem', { name: '加入收藏', exact: true }).click()
  await page.getByRole('button', { name: '返回技能列表', exact: true }).click()
  await page.getByRole('tab', { name: '收藏', exact: true }).click()
  await expect(page.getByRole('button', { name: /agents-sdk Build AI/ })).toBeVisible()
  await page.getByRole('button', { name: '数据源：项目资料', exact: true }).click()
  const before = await page.evaluate(id => window.boai.request('getDataSource', { id: id! }), sources.id)
  await runtime.restart()
  await runtime.page.getByRole('navigation', { name: '主导航' }).getByRole('button', { name: '自定义', exact: true }).click()
  await runtime.page.getByRole('button', { name: '数据源：项目资料', exact: true }).click()
  expect(await runtime.page.evaluate(id => window.boai.request('getDataSource', { id: id! }), sources.id)).toEqual(before)
  await runtime.app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].setContentSize(800, 680))
  expect(await runtime.page.locator('.custom-content').evaluate(element => { const box = element.getBoundingClientRect(); return box.right <= innerWidth && box.left >= 0 && element.scrollWidth <= element.clientWidth + 1 })).toBe(true)
  await runtime.reviewNativeCheckpoint('自定义整合与窄窗')
})
When('删除已绑定的本地数据源', async ({ runtime }) => {
  await runtime.page.getByRole('button', { name: '数据源更多操作', exact: true }).click()
  await runtime.page.getByRole('menuitem', { name: '删除数据源', exact: true }).click()
  await runtime.page.getByRole('dialog').getByRole('button', { name: '删除数据源', exact: true }).click()
  await expect(runtime.page.getByRole('dialog')).toHaveCount(0)
})
Then('员工授权已移除而文件夹原件保留', async ({ runtime, sources }) => {
  expect(await runtime.page.evaluate(() => window.boai.request('listDataSources', undefined))).toEqual([])
  expect((await runtime.page.evaluate(() => window.boai.request('snapshot', undefined))).agents.find(agent => agent.id === 'researcher')?.sourceIds).toEqual([])
  expect(await readFile(join(sources.folder!, 'facts.md'), 'utf8')).toBe('SOURCE_ORIGINAL')
  expect(runtime.errors).toEqual([])
})
When('添加使用密钥的本地API数据源并测试连接', async ({ runtime, sources }) => {
  const server = createServer((req, res) => { sources.requests++; res.writeHead(req.headers.authorization === 'Bearer SOURCE_UI_SECRET' ? 200 : 401, { 'Content-Type': 'application/json' }); res.end('{"ok":true}') })
  runtime.trackServer(server); await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  const page = runtime.page
  await page.getByRole('button', { name: '添加数据源', exact: true }).first().click(); await page.getByRole('menuitem', { name: 'API', exact: true }).click()
  await page.getByRole('textbox', { name: '名称', exact: true }).fill('业务 API')
  await page.getByRole('textbox', { name: 'Base URL', exact: true }).fill(`http://127.0.0.1:${(server.address() as { port: number }).port}/v1`)
  await page.getByRole('combobox', { name: '认证方式', exact: true }).click(); await page.getByRole('option', { name: 'Bearer token', exact: true }).click()
  await page.getByLabel('访问密钥', { exact: true }).fill('SOURCE_UI_SECRET')
  await page.getByRole('button', { name: '保存数据源', exact: true }).click(); await expect(page.getByRole('dialog')).toHaveCount(0)
  expect(sources.requests).toBe(0)
  sources.id = (await page.evaluate(() => window.boai.request('listDataSources', undefined)))[0].id
  await page.getByRole('button', { name: '测试连接', exact: true }).click(); await expect(page.getByText('连接正常', { exact: true })).toBeVisible(); expect(sources.requests).toBe(1)
  await runtime.reviewNativeCheckpoint('API真实测试通过')
})
Then('密钥未回显且停用和MCP配置均可保存', async ({ runtime, sources }) => {
  const page = runtime.page
  expect(JSON.stringify(await page.evaluate(() => window.boai.request('listDataSources', undefined)))).not.toContain('SOURCE_UI_SECRET')
  await page.getByRole('button', { name: '编辑配置', exact: true }).click(); await expect(page.getByLabel('访问密钥', { exact: true })).toHaveValue('')
  await page.getByRole('button', { name: '取消', exact: true }).click(); await expect(page.getByRole('dialog')).toHaveCount(0)
  await page.getByRole('button', { name: '数据源更多操作', exact: true }).click(); await page.getByRole('menuitem', { name: '停用数据源', exact: true }).click()
  await expect(page.getByRole('button', { name: '测试连接', exact: true })).toBeDisabled()
  await page.getByRole('button', { name: '返回数据源列表', exact: true }).click()
  await page.getByRole('button', { name: '添加数据源', exact: true }).first().click(); await page.getByRole('menuitem', { name: 'MCP', exact: true }).click()
  await page.getByRole('textbox', { name: '名称', exact: true }).fill('工具服务')
  await page.getByRole('textbox', { name: '服务地址', exact: true }).fill('http://127.0.0.1:9/mcp')
  await page.getByRole('button', { name: '保存数据源', exact: true }).click(); await expect(page.getByRole('dialog')).toHaveCount(0)
  expect((await page.evaluate(() => window.boai.request('listDataSources', undefined))).map(source => source.type).sort()).toEqual(['api', 'mcp'])
  expect(sources.requests).toBe(1)
  await runtime.reviewNativeCheckpoint('MCP配置与混合已安装列表')
  expect(runtime.errors).toEqual([])
})
