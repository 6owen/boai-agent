// Generated from: tests/e2e/features/composer.feature
import { test } from "../tests/e2e/steps/composer.steps.ts";

test.describe('会话轻量模型与命令菜单', () => {

  test('模型只在当前连接内切换且保留草稿与权限', { tag: ['@electron', '@composer'] }, async ({ Given, When, Then, runtime, scenario }) => { 
    await Given('输入框具备当前连接的模型目录和独立员工', null, { runtime, scenario }); 
    await When('切换当前连接内模型并检查窄窗口', null, { runtime, scenario }); 
    await Then('重启仍保留模型且权限与另一个员工未变化', null, { runtime, scenario }); 
  });

  test('模型保存失败不显示成功或自动重试', { tag: ['@electron', '@composer'] }, async ({ Given, When, Then, runtime, scenario }) => { 
    await Given('输入框具备当前连接的模型目录和独立员工', null, { runtime, scenario }); 
    await When('下一次模型保存失败', null, { runtime }); 
    await Then('模型显示仍与已保存配置一致且需核对配置', null, { runtime }); 
  });

  test('斜线命令与技能文件提及保留准确来源', { tag: ['@electron', '@composer'] }, async ({ Given, When, Then, runtime, scenario }) => { 
    await Given('输入框具备当前连接的模型目录和独立员工', null, { runtime, scenario }); 
    await When('使用斜线菜单并提及已绑定技能和已发送文件', null, { runtime, scenario }); 
    await Then('资源引用随消息受理且群聊成员提及仍可用', null, { runtime, scenario }); 
  });

  test('支持的模型通过二级菜单保存推理强度', { tag: ['@electron', '@composer'] }, async ({ Given, When, Then, runtime, scenario }) => { 
    await Given('输入框具备当前连接的模型目录和独立员工', null, { runtime, scenario }); 
    await When('打开支持模型的推理子菜单并保存低强度', null, { runtime, scenario }); 
    await Then('推理设置重启后仍保留且模型连接未变化', null, { runtime, scenario }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('tests/e2e/features/composer.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":8,"tags":["@electron","@composer"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"假如输入框具备当前连接的模型目录和独立员工","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":10,"keywordType":"Action","textWithKeyword":"当切换当前连接内模型并检查窄窗口","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":11,"keywordType":"Outcome","textWithKeyword":"那么重启仍保留模型且权限与另一个员工未变化","stepMatchArguments":[]}]},
  {"pwTestLine":12,"pickleLine":13,"tags":["@electron","@composer"],"steps":[{"pwStepLine":13,"gherkinStepLine":14,"keywordType":"Context","textWithKeyword":"假如输入框具备当前连接的模型目录和独立员工","stepMatchArguments":[]},{"pwStepLine":14,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"当下一次模型保存失败","stepMatchArguments":[]},{"pwStepLine":15,"gherkinStepLine":16,"keywordType":"Outcome","textWithKeyword":"那么模型显示仍与已保存配置一致且需核对配置","stepMatchArguments":[]}]},
  {"pwTestLine":18,"pickleLine":18,"tags":["@electron","@composer"],"steps":[{"pwStepLine":19,"gherkinStepLine":19,"keywordType":"Context","textWithKeyword":"假如输入框具备当前连接的模型目录和独立员工","stepMatchArguments":[]},{"pwStepLine":20,"gherkinStepLine":20,"keywordType":"Action","textWithKeyword":"当使用斜线菜单并提及已绑定技能和已发送文件","stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":21,"keywordType":"Outcome","textWithKeyword":"那么资源引用随消息受理且群聊成员提及仍可用","stepMatchArguments":[]}]},
  {"pwTestLine":24,"pickleLine":23,"tags":["@electron","@composer"],"steps":[{"pwStepLine":25,"gherkinStepLine":24,"keywordType":"Context","textWithKeyword":"假如输入框具备当前连接的模型目录和独立员工","stepMatchArguments":[]},{"pwStepLine":26,"gherkinStepLine":25,"keywordType":"Action","textWithKeyword":"当打开支持模型的推理子菜单并保存低强度","stepMatchArguments":[]},{"pwStepLine":27,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"那么推理设置重启后仍保留且模型连接未变化","stepMatchArguments":[]}]},
]; // bdd-data-end