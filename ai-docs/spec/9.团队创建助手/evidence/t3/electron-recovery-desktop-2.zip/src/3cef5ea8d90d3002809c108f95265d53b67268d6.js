// Generated from: tests/e2e/features/werewolf.feature
import { test } from "../tests/e2e/support/test.ts";

test.describe('正式狼人杀与玩家私密视角', () => {

  test('同一员工收到本局私聊并继续完成六人局', async ({ Given, When, Then, runtime }) => { 
    await Given('在隔离桌面准备六名狼人杀玩家', null, { runtime }); 
    await When('发牌并私聊女巫后重启桌面', null, { runtime }); 
    await Then('重启保留身份和私聊且不自动调用模型', null, { runtime }); 
    await When('明确继续到本局胜负结算', null, { runtime }); 
    await Then('本局私聊只进入女巫决策且普通记忆不被改变', null, { runtime }); 
  });

  test('游戏中断时暂停且不盲目重发未知请求', async ({ Given, When, Then, runtime }) => { 
    await Given('在隔离桌面准备六名狼人杀玩家', null, { runtime }); 
    await When('在真实模型请求期间暂停并重启游戏', null, { runtime }); 
    await Then('未知用量阻止继续且可以结束后创建新局', null, { runtime }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('tests/e2e/features/werewolf.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":7,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":8,"keywordType":"Context","textWithKeyword":"假如在隔离桌面准备六名狼人杀玩家","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":9,"keywordType":"Action","textWithKeyword":"当发牌并私聊女巫后重启桌面","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":10,"keywordType":"Outcome","textWithKeyword":"那么重启保留身份和私聊且不自动调用模型","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":11,"keywordType":"Action","textWithKeyword":"当明确继续到本局胜负结算","stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":12,"keywordType":"Outcome","textWithKeyword":"那么本局私聊只进入女巫决策且普通记忆不被改变","stepMatchArguments":[]}]},
  {"pwTestLine":14,"pickleLine":14,"tags":[],"steps":[{"pwStepLine":15,"gherkinStepLine":15,"keywordType":"Context","textWithKeyword":"假如在隔离桌面准备六名狼人杀玩家","stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"当在真实模型请求期间暂停并重启游戏","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":17,"keywordType":"Outcome","textWithKeyword":"那么未知用量阻止继续且可以结束后创建新局","stepMatchArguments":[]}]},
]; // bdd-data-end