/*
 * [INPUT]: 中文游戏场景、生产 Electron/IPC/renderer 和离线 SSE 端点。
 * [OUTPUT]: 身份通知/私聊/完整局、暂停/重启零自动重发与未知回执 UI 断言及截图。
 * [POS]: T3.4 桌面业务步骤；数据/协议来自共享 fixture。
 * [PROTOCOL]: 一旦本文件变化，必须同步更新 Header，并上浮检查所属目录 .folder.md。
 */
import { expect } from '@playwright/test'
import { createBdd } from 'playwright-bdd'
import { test } from '../support/test'
import type { Desktop } from '../support/desktop'
import { gameModelServer } from '../../fixtures/game-model'
import type { GameObserverView } from '../../../src/shared/domain'
const { Given, When, Then } = createBdd(test)
const state = new WeakMap<Desktop, { server: Awaited<ReturnType<typeof gameModelServer>>; conversationId: string; witch?: string; game?: GameObserverView }>()
const pane = (runtime: Desktop) => runtime.page.getByRole('region', { name: '正式狼人杀' })
async function open(runtime: Desktop) { await expect(runtime.page.locator('.app-shell')).toBeVisible(); await runtime.page.getByRole('button', { name: /玩狼人杀/, exact: false }).first().click() }
const latest = (runtime: Desktop) => runtime.page.evaluate(conversationId => window.boai.request('getGame', { conversationId }), state.get(runtime)!.conversationId)
Given('在隔离桌面准备六名狼人杀玩家', async ({ runtime }) => {
  const server = await gameModelServer(); runtime.defer(() => server.close()); await runtime.start()
  const conversationId = await runtime.page.evaluate(async url => {
    const connection = await window.boai.request('saveConnection', { name: '游戏离线验收', provider: 'openai-compatible', baseUrl: url, defaultModel: 'fixture' })
    const players = []
    for (let i = 0; i < 6; i++) players.push(await window.boai.request('saveAgent', { name: `局内玩家${i + 1}`, role: '普通员工', instructions: '简短中文', color: '#6c7c59', connectionId: connection.id, modelId: 'fixture', skillIds: [], knowledgeIds: [], active: true, allowCommands: false }))
    return (await window.boai.request('createConversation', { kind: 'group', title: '玩狼人杀', agentIds: players.map(p => p.id) })).id
  }, server.url)
  state.set(runtime, { server, conversationId }); await open(runtime)
  await pane(runtime).getByRole('button', { name: '玩狼人杀', exact: true }).click(); await pane(runtime).getByRole('button', { name: '发牌开始新局', exact: true }).click()
  await expect(pane(runtime).getByRole('button', { name: '继续游戏', exact: true })).toBeVisible()
})
When('发牌并私聊女巫后重启桌面', async ({ runtime }) => {
  const s = state.get(runtime)!, game = (await latest(runtime))!, witch = game.players.find(p => p.role === 'witch')!
  s.game = game; s.witch = witch.agentId
  await pane(runtime).getByRole('combobox', { name: '查看玩家私密通知', exact: true }).click(); await runtime.page.getByRole('option', { name: `${witch.seat}号 ${witch.name}`, exact: true }).click()
  await expect(pane(runtime).getByText(`${witch.name} 的本局身份：女巫`, { exact: true })).toBeVisible()
  await pane(runtime).getByRole('textbox', { name: '本局私聊内容', exact: true }).fill('UI_PRIVATE_CANARY 谨慎用药，你仍是本局女巫')
  await pane(runtime).getByRole('button', { name: '发送本局私聊', exact: true }).click(); await expect(pane(runtime).getByText(/你：UI_PRIVATE_CANARY/)).toBeVisible()
  await runtime.restart(); await open(runtime)
})
Then('重启保留身份和私聊且不自动调用模型', async ({ runtime }) => {
  const s = state.get(runtime)!, game = (await latest(runtime))!
  expect(game.id).toBe(s.game!.id); expect(game.status).toBe('paused'); expect(game.players.find(p => p.agentId === s.witch)?.role).toBe('witch'); expect(game.privateMessages[0].content).toContain('UI_PRIVATE_CANARY'); expect(s.server.requests).toHaveLength(0)
})
When('明确继续到本局胜负结算', async ({ runtime }) => {
  await pane(runtime).getByRole('button', { name: '继续游戏', exact: true }).click()
  await expect.poll(async () => (await latest(runtime))?.status, { timeout: 15000 }).toBe('ended')
  await pane(runtime).getByRole('button', { name: '玩狼人杀', exact: true }).click()
  await expect(pane(runtime).getByRole('status')).toContainText('获胜')
})
Then('本局私聊只进入女巫决策且普通记忆不被改变', async ({ runtime }) => {
  const s = state.get(runtime)!, game = (await latest(runtime))!
  expect(s.server.views.some(v => v.playerId === s.witch && JSON.stringify(v).includes('UI_PRIVATE_CANARY'))).toBe(true)
  expect(s.server.views.filter(v => v.playerId !== s.witch).every(v => !JSON.stringify(v).includes('UI_PRIVATE_CANARY'))).toBe(true)
  const checks = await runtime.page.evaluate(async input => ({ detail: await window.boai.request('getConversation', { id: input.id }), memories: await Promise.all(input.players.map(agentId => window.boai.request('getMemory', { agentId, scope: 'employee' }))) }), { id: s.conversationId, players: game.players.map(p => p.agentId) })
  expect(JSON.stringify(checks.detail.messages)).not.toContain('UI_PRIVATE_CANARY'); expect(checks.detail.workItems).toHaveLength(0); expect(checks.memories.every(m => m.entries.length === 0)).toBe(true)
  await test.info().attach('正式游戏完成', { body: await runtime.page.screenshot(), contentType: 'image/png' }); expect(runtime.errors).toEqual([]); expect(s.server.errors).toEqual([])
})
When('在真实模型请求期间暂停并重启游戏', async ({ runtime }) => {
  const s = state.get(runtime)!; s.server.state.hold = true
  await pane(runtime).getByRole('button', { name: '继续游戏', exact: true }).click(); await expect.poll(() => s.server.requests.length).toBe(1)
  await pane(runtime).getByRole('button', { name: '暂停游戏', exact: true }).click(); await expect.poll(async () => (await latest(runtime))?.unknownUsage).toBe(true)
  await runtime.restart(); await open(runtime)
})
Then('未知用量阻止继续且可以结束后创建新局', async ({ runtime }) => {
  const s = state.get(runtime)!; expect(s.server.requests).toHaveLength(1); const old = (await latest(runtime))!
  await pane(runtime).getByRole('button', { name: /狼人杀.*已暂停/ }).click(); await expect(pane(runtime).getByRole('status')).toContainText('未知用量')
  await pane(runtime).getByRole('button', { name: '继续游戏', exact: true }).click(); await expect(pane(runtime).getByRole('alert')).toContainText('无法继续'); expect(s.server.requests).toHaveLength(1)
  await pane(runtime).getByRole('button', { name: '结束并复盘', exact: true }).click(); await pane(runtime).getByRole('button', { name: '发牌开始新局', exact: true }).click()
  expect((await latest(runtime))!.id).not.toBe(old.id); expect((await latest(runtime))!.privateMessages).toHaveLength(0); expect(s.server.requests).toHaveLength(1)
  await test.info().attach('游戏未知回执恢复', { body: await runtime.page.screenshot(), contentType: 'image/png' }); expect(runtime.errors).toEqual([])
})
